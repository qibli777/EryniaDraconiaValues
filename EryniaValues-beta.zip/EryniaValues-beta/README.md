# EryniaValues.github.io
The EryniaValues Quiz, based on the 8values Political Quiz, measures your political ideology on 4 axes and determines which Erynia and Draconia political party best matches with your views.
